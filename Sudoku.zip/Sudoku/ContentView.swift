//
//  ContentView.swift
//  Sudoku
//
//  Created by Sean Sullivan on 3/5/25.
//

import SwiftUI

struct ContentView: View {
    // Game settings
    @State private var selectedBoardSize: BoardSize = .standard
    @State private var selectedDifficulty: Difficulty = .easy
    
    // Game model - initialize in init()
    @StateObject private var game: SudokuGame
    
    // View-level state for timer and mistakes
    @State private var elapsedSeconds: Int = 0
    @State private var mistakes: Int = 0
    @State private var timer: Timer? = nil
    
    // Initialize with default settings
    init() {
        // Create the game with initial settings
        _game = StateObject(wrappedValue: SudokuGame(
            boardSize: .standard,
            difficulty: .easy
        ))
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 16) {
                // Board size and difficulty selectors
                HStack {
                    Picker("Size", selection: $selectedBoardSize) {
                        Text("9×9").tag(BoardSize.standard)
                        Text("12×12").tag(BoardSize.medium)
                        Text("16×16").tag(BoardSize.large)
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    
                    Spacer()
                    
                    Picker("Difficulty", selection: $selectedDifficulty) {
                        Text("Easy").tag(Difficulty.easy)
                        Text("Medium").tag(Difficulty.medium)
                        Text("Hard").tag(Difficulty.hard)
                        Text("Expert").tag(Difficulty.expert)
                    }
                    .pickerStyle(SegmentedPickerStyle())
                }
                .padding(.vertical, 8)
                .onChange(of: selectedBoardSize) { oldValue, newValue in
                    updateGameSettings()
                }
                .onChange(of: selectedDifficulty) { oldValue, newValue in
                    updateGameSettings()
                }
                
                // Control panel with timer and mistakes
                ControlPanelView(
                    game: game,
                    formattedTime: formattedTime,
                    mistakes: mistakes,
                    onTogglePause: togglePause,
                    onReset: resetGame,
                    onGetHint: { game.getHint() }
                )
                
                // Board view
                BoardView(game: game)
                
                // Number pad
                NumberPadView(game: game)
                
                Spacer()
            }
            .padding()
            .navigationTitle("Sudoku")
            .onAppear {
                // Start the timer and observe notifications when view appears
                startTimer()
                setupNotificationObservers()
            }
            .onDisappear {
                // Cleanup when view disappears
                stopTimer()
                removeNotificationObservers()
            }
        }
    }
    
    // Format the elapsed time as mm:ss
    private var formattedTime: String {
        let minutes = elapsedSeconds / 60
        let seconds = elapsedSeconds % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
    
    // Start the timer
    private func startTimer() {
        // Cancel any existing timer
        stopTimer()
        
        // Create a new timer that fires every second
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            if !self.game.isGamePaused {
                DispatchQueue.main.async {
                    self.elapsedSeconds += 1
                    print("Timer tick: \(self.elapsedSeconds) seconds")
                }
            }
        }
        
        // Make sure the timer runs even during scrolling
        if let timer = timer {
            RunLoop.main.add(timer, forMode: .common)
        }
        
        print("Timer started in ContentView")
    }
    
    // Stop the timer
    private func stopTimer() {
        timer?.invalidate()
        timer = nil
    }
    
    // Set up notification observers
    private func setupNotificationObservers() {
        // Listen for invalid move notifications from the game model
        NotificationCenter.default.addObserver(
            forName: NSNotification.Name("InvalidMove"),
            object: nil,
            queue: .main
        ) { _ in
            self.mistakes += 1
            print("Mistake count increased to: \(self.mistakes)")
        }
    }
    
    // Remove notification observers
    private func removeNotificationObservers() {
        NotificationCenter.default.removeObserver(self)
    }
    
    // Toggle pause state
    private func togglePause() {
        game.togglePause()
    }
    
    // Reset the game
    private func resetGame() {
        // Reset local state
        elapsedSeconds = 0
        mistakes = 0
        
        // Reset the game model
        game.resetGame()
        
        print("Game reset in ContentView")
    }
    
    // Update game settings when board size or difficulty changes
    private func updateGameSettings() {
        // Stop the timer
        stopTimer()
        
        // Reset local state
        elapsedSeconds = 0
        mistakes = 0
        
        // Instead of creating a new game instance, update the existing one
        game.resetWithNewSettings(
            boardSize: selectedBoardSize,
            difficulty: selectedDifficulty
        )
        
        // Restart the timer
        startTimer()
        
        print("Game settings updated - Size: \(selectedBoardSize.description), Difficulty: \(selectedDifficulty.rawValue)")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
