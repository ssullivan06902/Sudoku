//
//  SudokuGenerator.swift
//  Sudoku
//
//  Created by Sean Sullivan on 3/5/25.
//

import Foundation

class SudokuGenerator {
    private var boardSize: BoardSize
    private var difficulty: Difficulty
    
    // Always use 1-9 for all board sizes
    private let maxNumber = 9
    
    init(boardSize: BoardSize, difficulty: Difficulty = .easy) {
        self.boardSize = boardSize
        self.difficulty = difficulty
    }
    
    func getBoard() -> [[Int]] {
        // First, get a base board for the selected size
        var board: [[Int]]
        switch boardSize {
        case .standard:
            board = getRandomStandardBoard()
        case .medium:
            board = getRandomMediumBoard()
        case .large:
            board = getRandomLargeBoard()
        }
        
        // Then apply difficulty by removing more numbers
        applyDifficulty(to: &board)
        
        return board
    }
    
    // Get a random 9×9 board
    private func getRandomStandardBoard() -> [[Int]] {
        // Generate a solved standard board
        var board = Array(repeating: Array(repeating: 0, count: 9), count: 9)
        
        // Use recursive backtracking to fill the board
        let _ = fillBoard(board: &board, row: 0, col: 0)
        
        // Apply random transformations to create variations
        applyRandomTransformations(board: &board)
        
        return board
    }
    
    // Get a random 12×12 board
    private func getRandomMediumBoard() -> [[Int]] {
        // For a 12×12 board, we'll fill four 9×9 regions with valid Sudoku patterns
        // and ensure they don't conflict at the boundaries
        var board = Array(repeating: Array(repeating: 0, count: 12), count: 12)
        
        // Generate pattern for top-left 9×9 region
        var topLeft = Array(repeating: Array(repeating: 0, count: 9), count: 9)
        let _ = fillBoard(board: &topLeft, row: 0, col: 0)
        
        // Copy the pattern to the board
        for row in 0..<9 {
            for col in 0..<9 {
                board[row][col] = topLeft[row][col]
            }
        }
        
        // Fill the other regions with patterns that don't conflict
        fillRemainingRegions(board: &board, basePattern: topLeft)
        
        // Apply random transformations
        applyRandomTransformations(board: &board)
        
        return board
    }
    
    // Get a random 16×16 board
    private func getRandomLargeBoard() -> [[Int]] {
        // For a 16×16 board, we'll fill it with four non-overlapping 9×9 regions
        var board = Array(repeating: Array(repeating: 0, count: 16), count: 16)
        
        // Generate four different 9×9 patterns
        var pattern1 = Array(repeating: Array(repeating: 0, count: 9), count: 9)
        var pattern2 = Array(repeating: Array(repeating: 0, count: 9), count: 9)
        var pattern3 = Array(repeating: Array(repeating: 0, count: 9), count: 9)
        var pattern4 = Array(repeating: Array(repeating: 0, count: 9), count: 9)
        
        let _ = fillBoard(board: &pattern1, row: 0, col: 0)
        let _ = fillBoard(board: &pattern2, row: 0, col: 0)
        let _ = fillBoard(board: &pattern3, row: 0, col: 0)
        let _ = fillBoard(board: &pattern4, row: 0, col: 0)
        
        // Apply patterns to the four quadrants
        fillLargeBoardWithPatterns(board: &board, patterns: [pattern1, pattern2, pattern3, pattern4])
        
        // Apply random transformations
        applyRandomTransformations(board: &board)
        
        return board
    }
    
    // Helper method to fill remaining regions of a medium board
    private func fillRemainingRegions(board: inout [[Int]], basePattern: [[Int]]) {
        // Top-right region (0-8, 9-11)
        for row in 0..<9 {
            for col in 9..<12 {
                let baseValue = basePattern[row][(col - 9) % 9]
                let shiftedValue = (baseValue % 9) + 1
                if isValidForRegion(board: board, row: row, col: col, value: shiftedValue) {
                    board[row][col] = shiftedValue
                } else {
                    // If there's a conflict, find another valid number
                    for num in 1...9 {
                        if isValidForRegion(board: board, row: row, col: col, value: num) {
                            board[row][col] = num
                            break
                        }
                    }
                }
            }
        }
        
        // Bottom-left region (9-11, 0-8)
        for row in 9..<12 {
            for col in 0..<9 {
                let baseValue = basePattern[(row - 9) % 9][col]
                let shiftedValue = (baseValue % 9) + 1
                if isValidForRegion(board: board, row: row, col: col, value: shiftedValue) {
                    board[row][col] = shiftedValue
                } else {
                    for num in 1...9 {
                        if isValidForRegion(board: board, row: row, col: col, value: num) {
                            board[row][col] = num
                            break
                        }
                    }
                }
            }
        }
        
        // Bottom-right region (9-11, 9-11)
        for row in 9..<12 {
            for col in 9..<12 {
                let baseValue = basePattern[(row - 9) % 9][(col - 9) % 9]
                let shiftedValue = (baseValue % 9) + 1
                if isValidForRegion(board: board, row: row, col: col, value: shiftedValue) {
                    board[row][col] = shiftedValue
                } else {
                    for num in 1...9 {
                        if isValidForRegion(board: board, row: row, col: col, value: num) {
                            board[row][col] = num
                            break
                        }
                    }
                }
            }
        }
    }
    
    // Helper method to fill a large board with patterns
    private func fillLargeBoardWithPatterns(board: inout [[Int]], patterns: [[[Int]]]) {
        // Top-left (0-8, 0-8)
        for row in 0..<9 {
            for col in 0..<9 {
                board[row][col] = patterns[0][row][col]
            }
        }
        
        // Top-right (0-8, 9-15)
        for row in 0..<9 {
            for col in 0..<7 {
                board[row][col + 9] = patterns[1][row][col]
            }
        }
        
        // Bottom-left (9-15, 0-8)
        for row in 0..<7 {
            for col in 0..<9 {
                board[row + 9][col] = patterns[2][row][col]
            }
        }
        
        // Bottom-right (9-15, 9-15)
        for row in 0..<7 {
            for col in 0..<7 {
                board[row + 9][col + 9] = patterns[3][row][col]
            }
        }
        
        // Fill any remaining cells
        for row in 0..<boardSize.gridSize {
            for col in 0..<boardSize.gridSize {
                if board[row][col] == 0 {
                    for num in 1...9 {
                        if isValidForRegion(board: board, row: row, col: col, value: num) {
                            board[row][col] = num
                            break
                        }
                    }
                }
            }
        }
    }
    
    // Recursive backtracking algorithm to fill a Sudoku board
    private func fillBoard(board: inout [[Int]], row: Int, col: Int) -> Bool {
        let gridSize = board.count
        
        // If we've filled all cells, we're done
        if row >= gridSize {
            return true
        }
        
        // Move to the next cell
        let nextRow = (col + 1 >= gridSize) ? row + 1 : row
        let nextCol = (col + 1 >= gridSize) ? 0 : col + 1
        
        // If this cell already has a value, move to the next cell
        if board[row][col] != 0 {
            return fillBoard(board: &board, row: nextRow, col: nextCol)
        }
        
        // Try each number 1-9 in a random order
        let numbers = Array(1...9).shuffled()
        for num in numbers {
            // Check if this number is valid in this cell
            if isValid(board: board, row: row, col: col, value: num) {
                // Place the number and continue
                board[row][col] = num
                
                // Recursively fill the rest of the board
                if fillBoard(board: &board, row: nextRow, col: nextCol) {
                    return true
                }
                
                // If we couldn't complete the board, backtrack
                board[row][col] = 0
            }
        }
        
        // If no number worked, backtrack
        return false
    }
    
    // Check if a number is valid for a cell
    private func isValid(board: [[Int]], row: Int, col: Int, value: Int) -> Bool {
        let gridSize = board.count
        
        // Check row
        for c in 0..<gridSize {
            if board[row][c] == value {
                return false
            }
        }
        
        // Check column
        for r in 0..<gridSize {
            if board[r][col] == value {
                return false
            }
        }
        
        // Check box (sub-grid)
        let boxSize = Int(sqrt(Double(gridSize)))
        let boxRow = (row / boxSize) * boxSize
        let boxCol = (col / boxSize) * boxSize
        
        for r in 0..<boxSize {
            for c in 0..<boxSize {
                if board[boxRow + r][boxCol + c] == value {
                    return false
                }
            }
        }
        
        return true
    }
    
    // Check if a number is valid for a specific region of the board
    private func isValidForRegion(board: [[Int]], row: Int, col: Int, value: Int) -> Bool {
        // For larger boards, we only check within 9x9 regions
        let regionSize = 9
        let regionRow = (row / regionSize) * regionSize
        let regionCol = (col / regionSize) * regionSize
        
        // Check row within region
        for c in regionCol..<min(regionCol + regionSize, boardSize.gridSize) {
            if board[row][c] == value {
                return false
            }
        }
        
        // Check column within region
        for r in regionRow..<min(regionRow + regionSize, boardSize.gridSize) {
            if board[r][col] == value {
                return false
            }
        }
        
        // Check box (sub-grid)
        let boxSizeRows = boardSize.subGridSizeRows
        let boxSizeCols = boardSize.subGridSizeCols
        
        let boxStartRow = (row / boxSizeRows) * boxSizeRows
        let boxStartCol = (col / boxSizeCols) * boxSizeCols
        
        for r in boxStartRow..<min(boxStartRow + boxSizeRows, boardSize.gridSize) {
            for c in boxStartCol..<min(boxStartCol + boxSizeCols, boardSize.gridSize) {
                if board[r][c] == value {
                    return false
                }
            }
        }
        
        return true
    }
    
    // Apply random transformations to create variations of the same board
    private func applyRandomTransformations(board: inout [[Int]]) {
        // Get the number of boxes in the grid
        let boxSizeRows = boardSize.subGridSizeRows
        let boxSizeCols = boardSize.subGridSizeCols
        let numBoxesRow = boardSize.gridSize / boxSizeRows
        let numBoxesCol = boardSize.gridSize / boxSizeCols
        
        // Apply several random transformations
        for _ in 0..<5 {
            let transformation = Int.random(in: 0..<4)
            
            switch transformation {
            case 0:
                // Swap two rows within the same box band
                let boxBand = Int.random(in: 0..<numBoxesRow)
                let rowInBox1 = Int.random(in: 0..<boxSizeRows)
                let rowInBox2 = Int.random(in: 0..<boxSizeRows)
                swapRows(board: &board, row1: boxBand * boxSizeRows + rowInBox1, row2: boxBand * boxSizeRows + rowInBox2)
                
            case 1:
                // Swap two columns within the same box band
                let boxBand = Int.random(in: 0..<numBoxesCol)
                let colInBox1 = Int.random(in: 0..<boxSizeCols)
                let colInBox2 = Int.random(in: 0..<boxSizeCols)
                swapColumns(board: &board, col1: boxBand * boxSizeCols + colInBox1, col2: boxBand * boxSizeCols + colInBox2)
                
            case 2:
                // Swap two box bands (rows)
                if numBoxesRow >= 2 {
                    let band1 = Int.random(in: 0..<numBoxesRow)
                    let band2 = Int.random(in: 0..<numBoxesRow)
                    if band1 != band2 {
                        swapBoxBandsRows(board: &board, band1: band1, band2: band2)
                    }
                }
                
            case 3:
                // Swap two box bands (columns)
                if numBoxesCol >= 2 {
                    let band1 = Int.random(in: 0..<numBoxesCol)
                    let band2 = Int.random(in: 0..<numBoxesCol)
                    if band1 != band2 {
                        swapBoxBandsColumns(board: &board, band1: band1, band2: band2)
                    }
                }
                
            default:
                break
            }
        }
    }
    
    // Swap two rows
    private func swapRows(board: inout [[Int]], row1: Int, row2: Int) {
        let temp = board[row1]
        board[row1] = board[row2]
        board[row2] = temp
    }
    
    // Swap two columns
    private func swapColumns(board: inout [[Int]], col1: Int, col2: Int) {
        for row in 0..<board.count {
            let temp = board[row][col1]
            board[row][col1] = board[row][col2]
            board[row][col2] = temp
        }
    }
    
    // Swap two box bands (rows)
    private func swapBoxBandsRows(board: inout [[Int]], band1: Int, band2: Int) {
        let boxSize = boardSize.subGridSizeRows
        
        for i in 0..<boxSize {
            swapRows(board: &board, row1: band1 * boxSize + i, row2: band2 * boxSize + i)
        }
    }
    
    // Swap two box bands (columns)
    private func swapBoxBandsColumns(board: inout [[Int]], band1: Int, band2: Int) {
        let boxSize = boardSize.subGridSizeCols
        
        for i in 0..<boxSize {
            swapColumns(board: &board, col1: band1 * boxSize + i, col2: band2 * boxSize + i)
        }
    }
    
    // Apply difficulty by removing numbers
    private func applyDifficulty(to board: inout [[Int]]) {
        // Determine how many cells to remove based on difficulty
        let totalCells = boardSize.gridSize * boardSize.gridSize
        let baseRemovalPercentage: Double
        
        switch difficulty {
        case .easy:
            baseRemovalPercentage = 0.4  // Remove 40% of cells
        case .medium:
            baseRemovalPercentage = 0.5  // Remove 50% of cells
        case .hard:
            baseRemovalPercentage = 0.6  // Remove 60% of cells
        case .expert:
            baseRemovalPercentage = 0.7  // Remove 70% of cells
        }
        
        // Adjust for board size
        let adjustedRemovalPercentage: Double
        switch boardSize {
        case .standard:
            adjustedRemovalPercentage = baseRemovalPercentage
        case .medium:
            adjustedRemovalPercentage = baseRemovalPercentage + 0.05
        case .large:
            adjustedRemovalPercentage = baseRemovalPercentage + 0.1
        }
        
        let cellsToRemove = Int(Double(totalCells) * adjustedRemovalPercentage)
        
        // Get all cell positions
        var positions: [(row: Int, col: Int)] = []
        for row in 0..<boardSize.gridSize {
            for col in 0..<boardSize.gridSize {
                positions.append((row, col))
            }
        }
        
        // Shuffle positions to randomize removal
        positions.shuffle()
        
        // Remove cells
        var removed = 0
        
        for position in positions {
            let row = position.row
            let col = position.col
            
            // Save original value (unused variable warning fixed by using _)
            let _ = board[row][col]
            board[row][col] = 0
            
            // Check if we've removed enough cells
            removed += 1
            if removed >= cellsToRemove {
                break
            }
        }
        
        print("Created puzzle with \(removed) cells removed")
    }
}
